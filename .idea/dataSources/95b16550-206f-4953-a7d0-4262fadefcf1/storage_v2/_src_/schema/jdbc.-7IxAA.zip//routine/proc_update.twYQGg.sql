create
    definer = root@localhost procedure proc_update(IN idUp int, IN namUp varchar(100), IN ageUp int, IN sexUp bit)
begin
    update student set name=namUp,age=ageUp,sex=sexUp where id = idUp;
end;

